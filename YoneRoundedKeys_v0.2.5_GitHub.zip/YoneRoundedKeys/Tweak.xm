#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <CoreFoundation/CoreFoundation.h>
#import <math.h>
%config(generator=internal);
#if defined(__arm64e__)
#define RK_BUILD_ARCH @"arm64e"
#elif defined(__aarch64__)
#define RK_BUILD_ARCH @"arm64"
#else
#error Unsupported CPU architecture
#endif

static CFStringRef const RKDomain=CFSTR("com.yone.roundedkeys");
static BOOL RKEnabled=YES;
static CGFloat RKRadius=32, RKOpacity=0.85;
static NSHashTable<UIView *> *RKHosts;
static char RKOriginalKey, RKBackdropOriginalKey, RKBadgeKey;
static BOOL RKDiagnostics=YES, RKScanning=NO;
static void RKRefresh(void);

static CGFloat RKNumber(NSString *key, CGFloat fallback, CGFloat min, CGFloat max) {
    id value=CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)key,RKDomain));
    if (![value isKindOfClass:NSNumber.class]) return fallback;
    double n=[value doubleValue]; return isfinite(n) ? fmax(min,fmin(max,n)) : fallback;
}
static void RKRead(void) {
    CFPreferencesAppSynchronize(RKDomain);
    RKDiagnostics=RKNumber(@"Diagnostics",1,0,1)>0;
    RKEnabled=RKNumber(@"Enabled",1,0,1)>0;
    RKRadius=RKNumber(@"Radius",32,0,64);
    RKOpacity=1-RKNumber(@"Transparency",15,0,100)/100.0;
}
// Only named background views are faded. Key labels and key hit targets are untouched.
static BOOL RKIsBackdrop(UIView *v) {
    NSString *name=NSStringFromClass(v.class);
    return [name isEqual:@"UIKBInputBackdropView"] ||
           [name isEqual:@"UIKeyboardBackgroundView"];
}
static void RKFadeBackgrounds(UIView *root, BOOL enable) {
    if (RKIsBackdrop(root)) {
        NSNumber *old=objc_getAssociatedObject(root,&RKBackdropOriginalKey);
        if (enable) {
            if (!old) { old=@(root.alpha); objc_setAssociatedObject(root,&RKBackdropOriginalKey,old,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
            root.alpha=old.doubleValue*RKOpacity;
        } else if (old) {
            root.alpha=old.doubleValue;
            objc_setAssociatedObject(root,&RKBackdropOriginalKey,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        return; // Avoid fading both a backdrop and its descendants.
    }
    for (UIView *child in root.subviews) RKFadeBackgrounds(child,enable);
}
static void RKApply(UIView *host) {
    if (!NSThread.isMainThread) return;
    [RKHosts addObject:host];
    NSDictionary *old=objc_getAssociatedObject(host,&RKOriginalKey);
    // Do not style accessory-only hosts, detached hosts or narrow floating panels.
    BOOL active=RKEnabled && host.window && host.bounds.size.height>=180 && host.bounds.size.width>=250;
    if (active) {
        if (!old) {
            old=@{@"radius":@(host.layer.cornerRadius),@"masks":@(host.layer.masksToBounds),
                  @"corners":@(host.layer.maskedCorners),@"curve":host.layer.cornerCurve ?: kCACornerCurveCircular};
            objc_setAssociatedObject(host,&RKOriginalKey,old,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        [CATransaction begin]; [CATransaction setDisableActions:YES];
        host.layer.cornerRadius=MIN(RKRadius,MIN(host.bounds.size.width,host.bounds.size.height)/2);
        host.layer.maskedCorners=kCALayerMinXMinYCorner|kCALayerMaxXMinYCorner|kCALayerMinXMaxYCorner|kCALayerMaxXMaxYCorner;
        host.layer.cornerCurve=kCACornerCurveContinuous;
        host.layer.masksToBounds=YES;
        [CATransaction commit];
    } else if (old) {
        host.layer.cornerRadius=[old[@"radius"] doubleValue];
        host.layer.maskedCorners=[old[@"corners"] unsignedIntegerValue];
        host.layer.masksToBounds=[old[@"masks"] boolValue];
        host.layer.cornerCurve=old[@"curve"];
        objc_setAssociatedObject(host,&RKOriginalKey,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    RKFadeBackgrounds(host,active);
}
static void RKChanged(CFNotificationCenterRef c,void *o,CFStringRef n,const void *obj,CFDictionaryRef info) {
    dispatch_async(dispatch_get_main_queue(), ^{
        RKRead();
        RKRefresh();
    });
}

// Discover live instances after UIKit/TextInput views have loaded. No one-shot
// NSClassFromString check in the constructor and no private-class hook needed.
static BOOL RKHasClassName(UIView *v, NSString *name) {
    for (Class cls=v.class; cls; cls=class_getSuperclass(cls))
        if ([NSStringFromClass(cls) isEqualToString:name]) return YES;
    return NO;
}
static BOOL RKIsHost(UIView *v) {
    return RKHasClassName(v,@"UIInputSetHostView") || RKHasClassName(v,@"UIKeyboardImpl");
}
static void RKVisit(UIView *v, NSUInteger depth, NSUInteger *budget, NSMutableArray<UIView *> *targets) {
    if (!v || depth>24 || !*budget) return;
    --*budget;
    if (v.hidden || v.alpha<=0) return;
    if (RKIsHost(v)) [targets addObject:v];
    for (UIView *child in v.subviews) RKVisit(child,depth+1,budget,targets);
}
static void RKBadge(UIWindow *w, NSString *text, BOOL visible) {
    UILabel *badge=objc_getAssociatedObject(w,&RKBadgeKey);
    if (!visible) { badge.hidden=YES; return; }
    if (!badge) {
        badge=[UILabel new];
        badge.font=[UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightMedium];
        badge.textAlignment=NSTextAlignmentCenter;
        badge.textColor=UIColor.whiteColor;
        badge.backgroundColor=[UIColor.systemBlueColor colorWithAlphaComponent:0.9];
        badge.layer.cornerRadius=6; badge.clipsToBounds=YES;
        badge.userInteractionEnabled=NO;
        badge.accessibilityIdentifier=@"YoneRoundedKeys.Diagnostics";
        [w addSubview:badge];
        objc_setAssociatedObject(w,&RKBadgeKey,badge,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    badge.text=text; badge.hidden=NO;
    CGFloat width=MIN(360,MAX(0,w.bounds.size.width-24));
    badge.frame=CGRectMake((w.bounds.size.width-width)/2,w.safeAreaInsets.top+4,width,24);
    [w bringSubviewToFront:badge];
}
static void RKRefresh(void) {
    if (!NSThread.isMainThread || RKScanning) return;
    RKScanning=YES;
    @try {
        NSString *bundle=NSBundle.mainBundle.bundleIdentifier ?: @"";
        NSString *process=NSProcessInfo.processInfo.processName ?: @"";
        BOOL service=[process rangeOfString:@"TextInput" options:NSCaseInsensitiveSearch].location!=NSNotFound ||
                     [process rangeOfString:@"Keyboard" options:NSCaseInsensitiveSearch].location!=NSNotFound;
        BOOL active=UIApplication.sharedApplication.applicationState==UIApplicationStateActive;
        BOOL diagnoseApp=[bundle isEqualToString:@"com.apple.mobilenotes"] || [bundle isEqualToString:@"com.apple.Preferences"];
        NSMutableOrderedSet<UIWindow *> *windows=[NSMutableOrderedSet orderedSet];
        for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            if (!service && scene.activationState!=UISceneActivationStateForegroundActive) continue;
            [windows addObjectsFromArray:((UIWindowScene *)scene).windows];
        }
        // Some keyboard windows are not associated with an exposed UIWindowScene.
        if (active || service) [windows addObjectsFromArray:UIApplication.sharedApplication.windows];
        NSUInteger found=0, applied=0;
        for (UIWindow *w in windows) {
            if (w.hidden || w.alpha<=0) continue;
            NSString *name=NSStringFromClass(w.class);
            BOOL keyboardWindow=[name rangeOfString:@"Keyboard"].location!=NSNotFound ||
                                [name rangeOfString:@"TextEffects"].location!=NSNotFound;
            if (!keyboardWindow && !service) continue;
            NSMutableArray<UIView *> *targets=[NSMutableArray array];
            NSUInteger budget=1500;
            RKVisit(w,0,&budget,targets);
            for (UIView *v in targets) {
                ++found;
                RKApply(v);
                if (RKEnabled && v.window && v.bounds.size.height>=180 && v.bounds.size.width>=250) ++applied;
            }
        }
        // Restore detached/hidden hosts when disabled, even if not found this pass.
        if (!RKEnabled) for (UIView *v in RKHosts.allObjects) RKApply(v);
        NSString *status=[NSString stringWithFormat:@"Yone 0.2.5 %@ | %@ | 匹配%lu 应用%lu R%.0f",
            RK_BUILD_ARCH, RKEnabled ? @"开启" : @"关闭",(unsigned long)found,(unsigned long)applied,RKRadius];
        for (UIWindow *w in windows) {
            BOOL show=RKDiagnostics && active && diagnoseApp && w.isKeyWindow && !w.hidden;
            RKBadge(w,status,show);
        }
    } @finally { RKScanning=NO; }
}
%ctor {
    @autoreleasepool {
        RKHosts=[NSHashTable weakObjectsHashTable]; RKRead();
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),NULL,RKChanged,
            CFSTR("com.yone.roundedkeys/changed"),NULL,CFNotificationSuspensionBehaviorDeliverImmediately);
        dispatch_async(dispatch_get_main_queue(), ^{
            NSNotificationCenter *center=NSNotificationCenter.defaultCenter;
            for (NSString *name in @[UIKeyboardDidShowNotification,UIKeyboardDidChangeFrameNotification,
                                     UIApplicationDidBecomeActiveNotification]) {
                [center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
                    RKRead(); RKRefresh();
                }];
            }
            // Repeated discovery also covers views/classes created after injection.
            static dispatch_source_t timer;
            timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_main_queue());
            dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,0),NSEC_PER_SEC/2,NSEC_PER_SEC/10);
            dispatch_source_set_event_handler(timer,^{RKRead();RKRefresh();});
            dispatch_resume(timer);
        });
    }
}
