# Yone 键盘圆角 0.2.5 · GitHub 构建版

用于解决手机编译产物只有 arm64 的明确缺项。Makefile 指定 arm64 + arm64e，并使用 GitHub macOS runner 的 Apple Clang；动态库由 Theos 正常签名。键盘显示效果仍未实机验证。

## iPhone 操作

1. 新建或使用一个专门放本项目的 GitHub 仓库。用 Safari 的 GitHub 网页操作上传，必要时选择“请求桌面网站”。
2. 解压本包，把项目文件上传到仓库根目录。需要 Tweak.xm、Makefile、control、YoneRoundedKeys.plist、layout 和 scripts 目录。ZIP 本身上传后不会自动解压。
3. GitHub 上传器可能不显示隐藏目录 `.github`。在仓库选择 Add file → Create new file，将文件名填为 `.github/workflows/build.yml`，粘贴本包 workflow 的完整内容，再提交。为方便 iPhone 访问，本包另提供可见目录 workflow-copy/build.yml，内容与正式 workflow 相同；不要仅上传这个可见副本。
4. 打开仓库 Actions，选择 Build YoneRoundedKeys → Run workflow。
5. 成功后在本次运行底部下载 YoneRoundedKeys-build，内含 deb 和日志。先将 deb 发回检查后再安装。

工作流由你手动触发，不需要证书或仓库写入权限。运行会下载开源工具链。使用 GitHub 的构建额度；具体用量以你的账号为准。

## 构建验收

工作流从最终 deb 解包检查真实 arm64、arm64e 两个 slice 和签名记录，再使用 Apple lipo 与 codesign 校验。未同时通过就不会显示成功。也检查标准设置页和 UIKitCore/TextInputUI 过滤项。

诊断标记更新为 Yone 0.2.5，并显示当前运行的 CPU slice。保留原有诊断开关、圆角和透明度偏好。此包是源工程，不是已经构建的安装包；当前制作环境没有 macOS/Xcode，也没有执行该远程工作流。

## 来源

https://theos.dev/docs/arm64e-deployment
https://github.com/roothide/Developer
https://github.com/roothide/theos
