"""Verify actual Mach-O slices and resources; package Architecture is insufficient."""
import pathlib
import plistlib
import struct
import sys


def verify_binary(data):
    magic = data[:4]
    if magic == bytes.fromhex("cafebabe"):
        count = struct.unpack_from(">I", data, 4)[0]
        spans = []
        for i in range(count):
            cpu, sub, offset, size, alignment = struct.unpack_from(">5I", data, 8+i*20)
            assert offset+size <= len(data), "Invalid fat slice bounds"
            spans.append((offset, size, cpu, sub))
    elif magic == bytes.fromhex("cffaedfe"):
        spans = [(0, len(data), None, None)]
    else:
        raise AssertionError("Unsupported Mach-O format")
    arches = set()
    for offset, size, fat_cpu, fat_sub in spans:
        image = data[offset:offset+size]
        h = struct.unpack_from("<8I", image)
        assert h[0] == 0xfeedfacf and h[1] == 0x100000c and h[3] == 6
        if fat_cpu is not None:
            assert (h[1], h[2]) == (fat_cpu, fat_sub), "Fat and slice CPU mismatch"
        subtype = h[2] & 0xffffff
        arch = {0: "arm64", 2: "arm64e"}.get(subtype)
        assert arch, "Unknown CPU subtype"
        pos = 32
        signed = False
        for _ in range(h[4]):
            cmd, length = struct.unpack_from("<II", image, pos)
            assert length >= 8 and pos+length <= 32+h[5]
            if cmd == 0x1d:
                start, length_sig = struct.unpack_from("<II", image, pos+8)
                assert length_sig > 12 and start+length_sig <= len(image)
                assert struct.unpack_from(">I", image, start)[0] == 0xfade0cc0
                signed = True
            pos += length
        assert signed, "Missing embedded code signature: " + arch
        arches.add(arch)
    assert {"arm64", "arm64e"}.issubset(arches), "Missing CPU slice(s): " + str(arches)
    return arches


def main(root):
    base = pathlib.Path(root)
    lib = base / "Library/MobileSubstrate/DynamicLibraries/YoneRoundedKeys.dylib"
    arches = verify_binary(lib.read_bytes())
    filters = plistlib.loads(lib.with_suffix(".plist").read_bytes())
    assert {"com.apple.UIKitCore", "com.apple.TextInputUI"}.issubset(filters["Filter"]["Bundles"])
    pane = plistlib.loads((base / "Library/PreferenceLoader/Preferences/YoneRoundedKeys.plist").read_bytes())
    assert pane["entry"]["cell"] == "PSLinkCell"
    settings = {s["key"]: s for s in pane["items"] if "key" in s}
    assert {"Enabled", "Radius", "Transparency", "Diagnostics"}.issubset(settings)
    assert all(s["defaults"] == "com.yone.roundedkeys" for s in settings.values())
    print("PASS: signed CPU slices", sorted(arches), "; keyboard filters and standard settings present")


if __name__ == "__main__":
    main(sys.argv[1])
